package com.z.zdev.bean;

/**
 * Created by Zz on 2016/3/28.
 */
public class UserBean extends BaseBean {
    /** 用户对象 */
    private UserChilBean data;

    public UserChilBean getData() {
        return data;
    }

    public void setData(UserChilBean data) {
        this.data = data;
    }
}
