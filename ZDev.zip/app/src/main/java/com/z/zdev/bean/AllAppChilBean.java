package com.z.zdev.bean;

/**
 * @Project: HNCloud
 * @Title: UserBean.java
 * @Package com.linzi.hncloud.bean
 * @Description: TODO
 * @author zuolangguo
 * @date 2015年12月7日 上午10:59:17
 * @version V1.0
 */
public class AllAppChilBean {

	/** id */
	private int id;

	/** name */
	private String name;

	/** icon */
	private String icon;

	/** gateway */
	private String gateway;

	/** isSign */
	private String isSign;

	/** isSign */
	private String appId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getGateway() {
		return gateway;
	}

	public void setGateway(String gateway) {
		this.gateway = gateway;
	}

	public String getIsSign() {
		return isSign;
	}

	public void setIsSign(String isSign) {
		this.isSign = isSign;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

}
